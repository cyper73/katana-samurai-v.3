# Katana Samurai v3.0 - Guida Installazione

## Installazione Rapida

1. Estrai tutti i file in una directory
2. Installa le dipendenze: `pip install -r requirements.txt`
3. Avvia il programma: `python katana_gui.py`

## Requisiti Sistema

- Python 3.8+
- Librerie specificate in requirements.txt
- Sistema operativo: Windows, macOS, Linux

## Primo Avvio

1. Carica un PDF o immagini
2. Seleziona il profilo Samurai appropriato
3. Processa i documenti
4. **IMPORTANTE**: Prima di chiudere il programma, clicca "Addestra Agente" per salvare l'apprendimento

## Supporto

Per assistenza, consulta la documentazione inclusa:
- README_UTENTE.md - Guida utente completa
- README_GUI.md - Interfaccia grafica
- DOCUMENTAZIONE_KATANA.md - Documentazione tecnica

---

*In memory of Minoru Shigematsu*
*Dedicated to the spirit of continuous improvement and precision*
